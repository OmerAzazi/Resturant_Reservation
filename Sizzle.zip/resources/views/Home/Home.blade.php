<!-- header-->
@include('Home.Header')
<!--/.header-->
<!--banner-->
@include('Home.Banner')
<!--/banner-->
<!--cook-delecious-->
@include('Home.Cook')
<!--/cook-delecious-->
<!--services-->
@include('Home.Services')
<!--/services-->
<!--book-->
@include('Home.Book')
<!--/book-->
<!--featured-food-->
@include('Home.Featured')
<!--/featured-food-->
<!--getapp-->
<!-- @include('Home.Get') -->
<!--/getapp-->
<!--footer-->
@include('Home.Footer')
<!--/footer-->






   



 



   



