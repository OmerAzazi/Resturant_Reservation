   <section class="featured-food">
        <div class="container">
            <div class="row">
                <div class="heading">
                    <h2>Weekly Featured Food</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="food-item">
                        <h2>Breakfast</h2>
                        <?php $__currentLoopData = $breakfast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breakfast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="/Template/img/<?php echo e($breakfast->Food_img); ?>" alt="" style="height: 175px">
                        <div class="price">$<?php echo e($breakfast->Food_price); ?></div>
                        <div class="text-content">
                            <h4><?php echo e($breakfast->Food_name); ?></h4>
                            <p><?php echo e($breakfast->Food_description); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="food-item">
                        <h2>Lunch</h2>
                        <?php $__currentLoopData = $lunch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lunch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="/Template/img/<?php echo e($lunch->Food_img); ?>" alt="" style="height: 175px">
                        <div class="price">$<?php echo e($lunch->Food_price); ?></div>
                        <div class="text-content">
                            <h4><?php echo e($lunch->Food_name); ?></h4>
                            <p><?php echo e($lunch->Food_description); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="food-item">
                        <h2>Dinner</h2>
                        <?php $__currentLoopData = $dinner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dinner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="/Template/img/<?php echo e($dinner->Food_img); ?>" alt="" style="height: 175px">
                        <div class="price">$<?php echo e($dinner->Food_price); ?></div>
                        <div class="text-content">
                            <h4><?php echo e($dinner->Food_name); ?></h4>
                            <p><?php echo e($dinner->Food_description); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\xampp\htdocs\Sizzle\resources\views/Home/Featured.blade.php ENDPATH**/ ?>