<section class="banner">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <h4>Here you can find delecious foods</h4>
                <h2>Asian Restaurant</h2>
                <p>Sizzle & Spice is a culinary destination that tantalizes your taste buds with an enticing fusion of flavors and aromatic spices.</p>
                <div class="primary-button">
                    <a href="#" class="scroll-link" data-id="book-table">Order Right Now</a>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\Sizzle\resources\views/Home/Banner.blade.php ENDPATH**/ ?>