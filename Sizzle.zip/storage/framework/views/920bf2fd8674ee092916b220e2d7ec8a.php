<?php echo $__env->make('Home.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="page-heading">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Our Menus</h1>
                    <p>Delight in artful cuisine. Bold flavors and stunning presentations showcase our mastery of food. Join us for a sensory dining adventure that leaves a lasting impression. Indulge in the extraordinary.</p>
                </div>
            </div>
        </div>
    </section>



    <section class="breakfast-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="breakfast-menu-content">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="left-image">
                                    <img src="Template/img/breakfast_menu.jpg" alt="Breakfast">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <h2>Breakfast Menu</h2>
                                <div id="owl-breakfast" class="owl-carousel owl-theme">
                                    <?php $__currentLoopData = $breakfast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breakfast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="/Template/img/<?php echo e($breakfast->Food_img); ?>" alt="" style="height: 140px">
                                            <div class="price">$<?php echo e($breakfast->Food_price); ?></div>
                                            <div class="text-content">
                                                <h4><?php echo e($breakfast->Food_name); ?></h4>
                                                <p>
                                                    <?php echo e($breakfast->Food_description); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="lunch-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="lunch-menu-content">
                        <div class="row">
                            <div class="col-md-7">
                                <h2>Lunch Menu</h2>
                                <div id="owl-lunch" class="owl-carousel owl-theme">
                                    <?php $__currentLoopData = $lunch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lunch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="/Template/img/<?php echo e($lunch->Food_img); ?>" alt="" style="height: 140px">
                                            <div class="price">$<?php echo e($lunch->Food_price); ?></div>
                                            <div class="text-content">
                                                <h4><?php echo e($lunch->Food_name); ?></h4>
                                                <p><?php echo e($lunch->Food_description); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="left-image">
                                    <img src="Template/img/lunch_menu.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="dinner-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="dinner-menu-content">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="left-image">
                                    <img src="Template/img/dinner_menu.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <h2>Dinner Menu</h2>
                                <div id="owl-dinner" class="owl-carousel owl-theme">
                                    <?php $__currentLoopData = $desert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="/Template/img/<?php echo e($desert->Food_img); ?>" alt="" style="height: 140px">
                                            <div class="price">$<?php echo e($desert->Food_price); ?></div>
                                            <div class="text-content">
                                                <h4><?php echo e($desert->Food_name); ?></h4>
                                                <p><?php echo e($desert->Food_description); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





<?php echo $__env->make('Home.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sizzle\resources\views/Menu/Menu.blade.php ENDPATH**/ ?>