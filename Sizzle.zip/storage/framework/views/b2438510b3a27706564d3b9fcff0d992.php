<section class="get-app">
    <div class="container">
        <div class="row">
            <div class="heading">
                <h2>Get application for your phone</h2>
            </div>
            <div class="primary-white-button">
                <a href="#">Download now</a>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\Sizzle\resources\views/Home/Get.blade.php ENDPATH**/ ?>