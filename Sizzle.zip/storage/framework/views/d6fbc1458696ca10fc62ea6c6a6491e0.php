<!-- header-->
<?php echo $__env->make('Home.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/.header-->
<!--banner-->
<?php echo $__env->make('Home.Banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/banner-->
<!--cook-delecious-->
<?php echo $__env->make('Home.Cook', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/cook-delecious-->
<!--services-->
<?php echo $__env->make('Home.Services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/services-->
<!--book-->
<?php echo $__env->make('Home.Book', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/book-->
<!--featured-food-->
<?php echo $__env->make('Home.Featured', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/featured-food-->
<!--getapp-->
<!-- <?php echo $__env->make('Home.Get', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
<!--/getapp-->
<!--footer-->
<?php echo $__env->make('Home.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/footer-->






   



 



   



<?php /**PATH C:\xampp\htdocs\Sizzle\resources\views/Home/Home.blade.php ENDPATH**/ ?>